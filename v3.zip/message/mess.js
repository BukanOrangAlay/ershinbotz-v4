module.exports.mess = {
	        wait: 'PROSES...',
			success: 'DONE',
			wrongFormat: 'Format salah, coba liat lagi di menu',
			error: {
				api: 'APINYA HABIS BRO ISI ULANG DULU',
				stick: 'ITU BUKAN STIKER NGAB',
				Iv: 'JANGAN NGASIH LINK GAJE TOD'
			},
			only: {
				group: 'KHUSUS GRUP NGAB',
				admin: 'KHUSUS ADMIN NGAB',
				premium: 'LU BUKAN MEMBER PREMIUM NGAB',
				owner: 'KHUSUS OWNER NGAB',
				Badmin: 'BOT HARUS JADI ADMIN NGAB',
			}
		}